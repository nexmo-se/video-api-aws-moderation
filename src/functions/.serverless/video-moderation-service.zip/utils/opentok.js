const OpenTok = require("opentok");

const opentok = new OpenTok(
  process.env.OPENTOK_API_KEY,
  process.env.OPENTOK_API_SECRET
);

function createSession() {
  opentok.createSession(function (err, session) {
    if (err) {
      console.log(err);
      return new Error(err);
    }
    return session;
  });
}

function createToken(sessionId) {
  if (sessionId) {
    return opentok.generateToken(sessionId);
  }
  return new Error("SESSION_ID_NOT_VALID");
}

module.exports = {
  createSession,
  createToken,
};
