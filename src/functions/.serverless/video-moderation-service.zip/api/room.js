const { getRoom, createRoom } = require("../dynamodb/query");
const { createSession, createToken } = require("../utils/opentok");

async function handleRoomCreation(roomName) {
  if (!roomName) {
    throw new Error("[handleRoomCreation] - Room Name undefined");
  }
  let roomItem = getRoom(roomName);
  let sessionId = null;
  if (!roomItem) {
    // need to create room into DynamoDB and then sessionId
    sessionId = await createSession();
    roomItem = await createRoom(roomName, sessionId);
  } else {
    sessionId = roomItem.sessionId;
  }

  let token = createToken(sessionId);

  return { sessionId, room: roomItem.roomName, token };
}

module.exports.handler = async (event) => {
  let body = null;
  try {
    if (process.env.IS_LOCAL === "true") {
      body = event.body;
    } else {
      body = JSON.parse(event.body);
    }

    // todo probably check if Items is 0
    const { room, sessionId, token } = await handleRoomCreation(body.roomName);
    return {
      statusCode: 200,
      body: JSON.stringify({
        room,
        sessionId,
        token,
        apiKey: process.env.OPENTOK_API_KEY,
      }),
    };
  } catch (err) {
    return {
      statusCode: 500,
    };
  }
};
